package com.company;


import java.util.Scanner;

public class Email {

    private String firstName;
    private String lastName;
    private String passWord;
    private String department;
    private String email;
    private int mailboxCapacity;
    private int defaultPasswordLength = 10;
    private String alternateEmail;
    private String companySuffix = "mark254company.com";
    private String showInfo;

    //Constructor to receive firstName and lastName
    public Email(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        System.out.println("EMAIL CREATED: " + this.firstName + "" + this.lastName);

        //Call a method asking for the department and return the department
       this.department = setDepartment();
        System.out.println("Department: " +this.department);

        this.passWord = randomPassword(defaultPasswordLength);
        System.out.println("Your Password is: " + this.passWord);

        //Combine elements to create email
        email = firstName.toLowerCase() + "" + lastName.toLowerCase() + "@" + department + "." + companySuffix;

        this.showInfo = showInfo();
        System.out.println("Your email is: " + this.showInfo);
    }

 // Ask for the department
private String setDepartment(){
    System.out.println("DEPARTMENT CODES\n1 for sales\n2 for Development\n3 for Accounting\n0 for none\n Enter Department Code: ");
    Scanner in = new Scanner(System.in);
    int deptChoice = in.nextInt();
    if (deptChoice == 1){return "sales"; }
        else if(deptChoice ==2) {return "dev"; }
        else if(deptChoice ==3) {return "acct";}
        else{return "";}
    }
    //generate a random password
    private String randomPassword(int length){
        String passWordSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%";
        char[] passWord = new char[ length];
        for(int i=0; i<length; i++){
           int rand = (int)(Math.random() * passWordSet.length());
           passWord[i] = passWordSet.charAt(rand);
        }
        return new String(passWord);
    }

    public void setMailboxCapacity(int Capacity){
        this.mailboxCapacity = Capacity;
}
//set the alternate email
    public void setAlternateEmail(String altEmail){
        this.alternateEmail = altEmail;

    }

    //Change password
   public void changePassword(String passWord){
        this.passWord = passWord;
   }
 public int getMailboxCapacity(){return mailboxCapacity;}

    public String getAlternateEmail() {
        return alternateEmail;}

        public String getPassWord() {return passWord;}



        public String showInfo() {
            return "DISPLAY NAME: " + firstName + " " + lastName +
                    "COMPANY EMAIL: " + email +
                    "MAILBOX CAPACITY: " + mailboxCapacity + "mb";
        }
    }

