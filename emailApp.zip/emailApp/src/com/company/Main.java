package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Email em1 = new Email("Mark","Mark");
        em1.showInfo();

    }
}
